function g=gramm_eqAx(g,xbool,ybool)
% g=gramm_eqAx(g,xbool,ybool)
%     lims=[0 0];
    
for i=1:numel(g)
        if ~isempty(g(i).facet_axes_handles)
            if ybool
                ys=g(i).facet_axes_handles.YLim;
                if sum(isinf(ys))>0
                    g(i).facet_axes_handles.YLim=[0 1];
                    ys=[0 1];
                end
                    
                if i==1
                    ylims=ys;
                end
                if ys(1)<ylims(1)
                    ylims(1)=ys(1);
                end
                if ys(2)>ylims(2)
                    ylims(2)=ys(2);
                end
            end
            if xbool
                xs=g(i).facet_axes_handles.XLim;
                if i==1
                    xlims=xs;
                end
                if xs(1)<xlims(1)
                    xlims(1)=xs(1);
                end
                if xs(2)>xlims(2)
                    xlims(2)=xs(2);
                end
            end
        end
    end
    for i=1:numel(g)
        if ~isempty(g(i).facet_axes_handles)
            if ybool
                g(i).facet_axes_handles.YLim=ylims;
            end
            if xbool
                g(i).facet_axes_handles.XLim=xlims;
            end
        end

    end



end