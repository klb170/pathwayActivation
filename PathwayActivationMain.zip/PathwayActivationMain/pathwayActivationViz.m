clearvars; clc; close all;
load('RecruitmentData.mat')
% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 3 - generation of recruitment curve
% set colormap
pathcolors=[92 172 238;...
    255 164 0;...
    125 38 205;...
    0 0 255;...
    0 205 0;...
    100 100 100;...%200 200 200;...
    255 20 147;...
    0  0 0;...%183 171 80;...
    165 42 42];
pathcolors=pathcolors./255;
% choose pathway(s) to plot
pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[0 0 0 0 0 0 1 0 0];
clear g
plot_paths=find(paths);

% Dependent Parameters
polstr='cathodic';
pws=60;
contacts=567;
dxs=0.5;
pathname=pathnames{plot_paths(1)};
dx=0.5;
EL=14;
elecLoc='dlSTN';

% Create plots
for i=1:length(plot_paths)
    pathname=pathnames{plot_paths(i)};
    clear g
    [idx_subset,~]=find(ismember(RT2.(elecLoc).(polstr).pw,pws)&ismember(RT2.(elecLoc).(polstr).Contact,contacts)&ismember(RT2.(elecLoc).(polstr).dx,dxs));
    xs=RT2.(elecLoc).(polstr).Amp(idx_subset);
    ys=RT2.(elecLoc).(polstr).(pathname)(idx_subset); 
    grp=RT2.(elecLoc).(polstr).EL(idx_subset);
% 
    g(1,1)=gramm('x',xs,'y',ys,'linestyle',grp);
    g(1,1).geom_line()
    g(1,1).set_names('x','Amplitude (mA)','y','Recruitment (%)');
    g(1,1).set_color_options('map',ones(27,1)*[pathcolors(plot_paths(i),:)])
    g(1,1).set_line_options('style',{'-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-','-'})
    g(1,1).set_layout_options('legend',false)
    
    [idx_subset,~]=find(ismember(RT2.(elecLoc).(polstr).pw,pws)&ismember(RT2.(elecLoc).(polstr).Contact,contacts)&ismember(RT2.(elecLoc).(polstr).dx,dxs));

    % --------- str-Dur curve --------- %
    xs=RT2.(elecLoc).(polstr).Amp(idx_subset);
    ys=RT2.(elecLoc).(polstr).(pathname)(idx_subset);
    g(1,2)=gramm('x',xs,'y',ys);
    g(1,2).stat_summary('type','quartile'); 
    g(1,2).set_names('x','Amplitude (mA)','y','Recruitment (%)');
    g(1,2).set_color_options('map',[pathcolors(plot_paths(i),:)])

    figure
    g.set_text_options('base_size',15)
    g.draw()
    for j=1:2
        g(1,j).facet_axes_handles.YLim=[0 100];
    end
    set(gcf,'Position',[616 760 560 258])
    set(gcf,'Name',pathname)
end


% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 5: Effect of electrode location
elecLocations={'dlSTN','cSTN','pmdSTN'};
dxs=[0.5];

figure; %set(gcf,'Name',fn);
polstr='cathodic';

pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[1 1 0 1 1 1 1 1 1];
clear g
plot_paths=find(paths);
pathcolors=[92 172 238;...
    255 164 0;...
    125 38 205;...
    0 0 255;...
    0 205 0;...
    100 100 100;...
    255 20 147;...
    0  0 0;...
    165 42 42]./255/1;
for i_loc=1:length(elecLocations)
    elecLoc=elecLocations{i_loc};
    if strcmp(elecLoc,'dlSTN')
        elecLoc2='dSTN';
    elseif strcmp(elecLoc,'pmdSTN')
        elecLoc2='pdSTN';
    else
        elecLoc2=elecLoc;
    end
    for i_dx=1:length(dxs)
        dx=dxs(i_dx);
        cstr=[];
        xs=[]; ys=[]; cols=[]; colnames={};
        idx=find(([RT2.(elecLoc).(polstr).dx]==dx) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60));

        for i=1:sum(paths)
            pathname=pathnames{plot_paths(i)}; colnames{length(idx)}='a';
            [colnames{:}]=deal(pathname);
            cols=[cols;colnames'];
            xs=[xs;RT2.(elecLoc).(polstr).Amp(idx)];
            ys=[ys;RT2.(elecLoc).(polstr).(pathname)(idx)];
        end
        g(i_dx,i_loc)=gramm('x',xs,'y',ys,'color',cols);
        g(i_dx,i_loc).stat_summary('type','quartile');
        g(i_dx,i_loc).stat_summary('type','quartile');
        g(i_dx,i_loc).set_names('x','Amplitude (mA)','y','Recruitment (%)','color',' ');
        g(i_dx,i_loc).set_color_options('map',[pathcolors(plot_paths,:)]);
        g(i_dx,i_loc).set_order_options('color',0);
        g(i_dx,i_loc).set_title(elecLoc2);
        if i_loc==3
            g(i_dx,i_loc).set_layout_options('legend',true,'legend_position',[0.75 0.35 0.2 0.5]);
        else
            g(i_dx,i_loc).set_layout_options('legend',false);
        end
    end
end

g.set_text_options('base_size',15)
g.draw()

for i_loc=1:length(elecLocations)
    for i_dx=1:length(dxs)
        g(i_dx,i_loc).facet_axes_handles.YLim=[-5 100];
        g(i_dx,i_loc).facet_axes_handles.YLim=[0 100];
    end
end

set(gcf,'Position',[1 1 896 284]);

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 6: Effect of pulse width
dx=0.5;
elecLoc='dlSTN';
pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
% pathnames={'CT','ML','mHD','pHD','mIC','pIC','P','PS','STP'};
paths=[1 1 0 1 1 1 1 1 1];
plot_paths=find(paths);

figure
clear g
pws=[30 60 120]; nameOrder={};
for i_pw=1:length(pws)
    pw=pws(i_pw);
    polstr='cathodic';
    idx=find(([RT2.(elecLoc).(polstr).dx]==dx) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==pw));
    cols=[]; xs=[]; ys=[]; colnames={};
    for i=1:sum(paths)
        pathname=pathnames{plot_paths(i)};
        switch pathname
            case 'P'
                pathnameStr='Pallidothalamic';
            case 'CT'
                pathnameStr='Cerebellothalamic';
            case 'ML'
                pathnameStr='Medial Lemniscus';
            case 'PS'
                pathnameStr='Pallidosubthalamic';
            case 'STP'
                pathnameStr='Subthalamopallidal';
            case 'mIC'
                pathnameStr='Motor Internal Capsule';
                pathnameStr='Motor IC';
            case 'mHD'
                pathnameStr='Motor Hyperdirect';
                pathnameStr='Motor HDP';
            case 'pIC'
                pathnameStr='Prefrontal Internal Capsule';
                pathnameStr='Prefrontal IC';
            case 'pHD'
                pathnameStr='Prefrontal Hyperdirect';
                pathnameStr='Prefrontal HDP';
        end
        colnames{length(idx)}='a';
        if i_pw==1
            nameOrder{end+1}=pathnameStr;
        end
        [colnames{:}]=deal(pathnameStr);
        cols=[cols;colnames'];
        xs=[xs;RT2.(elecLoc).(polstr).Amp(idx)];
        ys=[ys;RT2.(elecLoc).(polstr).(pathname)(idx)];
    end
    g(1,i_pw) = gramm('x',xs,'y',ys,'color',cols);
    g(1,i_pw).stat_summary('type','quartile');
    g(1,i_pw).set_names('x','Amplitude (mA)','y','Recruitment (%)','color',' ');
    g(1,i_pw).set_title(sprintf('%0.0f us',pw));
    g(1,i_pw).set_color_options('map',[pathcolors(plot_paths,:)]);
    g(1,i_pw).set_order_options('color',0)
    if i_pw==3
        g(1,i_pw).set_layout_options('legend',true,'legend_position',[0.075 0.35 0.2 0.5]);
    else
        g(1,i_pw).set_layout_options('legend',false);
    end
end

g.set_text_options('base_size',15)
g.draw()
g(1,1).facet_axes_handles.YLim=[-5 100];
g(1,2).facet_axes_handles.YLim=[-5 100];
g(1,2).facet_axes_handles.XLim=g(1,1).facet_axes_handles.XLim;
g(1,3).facet_axes_handles.XLim=g(1,1).facet_axes_handles.XLim;

set(gcf,'Position',[897 2 896 305])

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 7: Effect of polarity
dx=0.5;
pw=60;
elecLoc='dlSTN';
pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[1 1 0 1 1 1 1 1 1];
plot_paths=find(paths);

figure
clear g
polstrs={'cathodic','anodic'};
for i_pol=1:length(polstrs)
    polstr=polstrs{i_pol};
    idx=find(([RT2.(elecLoc).(polstr).dx]==dx) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==pw));
    cols=[]; xs=[]; ys=[]; colnames={};
    for i=1:sum(paths)
        pathname=pathnames{plot_paths(i)};
        switch pathname
            case 'P'
                pathnameStr='Pallidothalamic';
            case 'CT'
                pathnameStr='Cerebellothalamic';
            case 'ML'
                pathnameStr='Medial Lemniscus';
            case 'PS'
                pathnameStr='Pallidosubthalamic';
            case 'STP'
                pathnameStr='Subthalamopallidal';
            case 'mIC'
                pathnameStr='Motor Internal Capsule';
                pathnameStr='Motor IC';
            case 'mHD'
                pathnameStr='Motor Hyperdirect';
                pathnameStr='Motor HDP';
            case 'pIC'
                pathnameStr='Prefrontal Internal Capsule';
                pathnameStr='Prefrontal IC';
            case 'pHD'
                pathnameStr='Prefrontal Hyperdirect';
                pathnameStr='Prefrontal HDP';
        end
        colnames{length(idx)}='a';
        [colnames{:}]=deal(pathnameStr);
        cols=[cols;colnames'];
        xs=[xs;RT2.(elecLoc).(polstr).Amp(idx)];
        ys=[ys;RT2.(elecLoc).(polstr).(pathname)(idx)];
    end
    g(1,i_pol) = gramm('x',xs,'y',ys,'color',cols);
    g(1,i_pol).stat_summary('type','quartile');
    if i_pol==1
        g(1,i_pol).set_names('x','Amplitude (mA)','y','Recruitment (%)','color',' ');%'Pathway');
    else
        g(1,i_pol).set_names('x','Amplitude (mA)','y',' ','color',' ');
        g(1,i_pol).set_layout_options('legend',false);
    end
    if i_pol==1
        g(1,i_pol).set_layout_options('legend',true,'legend_position',[0.1 0.5 0.2 0.4]);
    else
        g(1,i_pol).set_layout_options('legend',false);
    end
    g(1,i_pol).set_title(sprintf([polstr]));
    g(1,i_pol).set_color_options('map',[pathcolors(plot_paths,:)]);
    g(1,i_pol).set_order_options('color',0)
end

g.set_text_options('base_size',15)
g.draw()
g(1,1).facet_axes_handles.YLim=[-5 100];
g=gramm_eqAx(g,0,1);

set(gcf,'Position',[897     2   896/1.4   455/1.4])

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 8: Effect of Directionality
polstr='cathodic';
elecLoc='dlSTN';
amps=unique(RT2.(elecLoc).(polstr).Amp);
bbb=[]; ccc=[]; aaa=[]; params=[];
for i_amp=1:length(amps)
    for EL=1:27
        idx=find((RT2.(elecLoc).(polstr).Amp==amps(i_amp))&(RT2.(elecLoc).(polstr).EL==EL)&(RT2.(elecLoc).(polstr).dx==0.5)&(RT2.(elecLoc).(polstr).pw==60)&(RT2.(elecLoc).(polstr).ring==0));
        if numel(idx)==3 && numel(unique(RT2.(elecLoc).(polstr).Contact(idx)))==3
            params=[params;table2array(RT2.(elecLoc).(polstr)(idx,1:9))];
            aa=table2array(RT2.(elecLoc).(polstr)(idx,10:18));
            cc=mean(aa); % essentially "ring" mode
            bb=max(aa)-min(aa); % range of activation from choosing diff contacts
            aaa=[aaa;aa];
            bbb=[bbb;bb]; 
            ccc=[ccc;cc];
        end
    end
end
paths=ones([1,9]);
%
figure
xs=ones(size(bbb,1),9).*[1:9]; 

g=gramm('x',xs(:),'y',bbb(:),'color',xs(:),'subset',bbb(:)>0);
g.stat_boxplot('width',3.0)
g.set_color_options('map',pathcolors(find(max(bbb)>0),:))
g.set_text_options('base_size',15)
g.set_names('x',' ','y',sprintf('Difference in recruitment \nacross directional contacts (%%)'))
g.no_legend();
g.draw()

g.facet_axes_handles.XTickLabel=pathnames();
removegrammoutliers(g)
g.facet_axes_handles.YLim=[0 100];

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 9: Effect of electrode precision
% Recruitment plot --------------------------------------------- %
dxs=[0.5 1 1.5];
polstr='cathodic';
elecLocations={'dlSTN'};
elecLocStrs={'dlSTN'};
amps=unique(RT2.(elecLoc).(polstr).Amp);
clear pp
clear g
pathnames={'CT'};
pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[1 1 0 1 1 1 1 1 1];
figure
plot_paths=find(paths);
pathcolors=[92 172 238;...
    255 164 0;...
    125 38 205;...
    0 0 255;...
    0 205 0;...
    100 100 100;...%200 200 200;...
    255 20 147;...
    0  0 0;...%183 171 80;...
    165 42 42]./255/1;
for i_loc=1:length(elecLocStrs)
    elecLoc=elecLocStrs{i_loc};
    elecLocStr=elecLocStrs{i_loc};
    for i_dx=1:length(dxs)
        dx=dxs(i_dx);
        cstr=[];
        xs=[]; ys=[]; cols=[]; colnames={};
        idx=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==dx) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60));
        if ~isempty(idx)
            for i=1:sum(paths)
                pathname=pathnames{plot_paths(i)}; colnames{length(idx)}='a';
                [colnames{:}]=deal(pathname);
                cols=[cols;colnames'];
                xs=[xs;RT2.(elecLoc).(polstr).Amp(idx)];
                ys=[ys;RT2.(elecLoc).(polstr).(pathname)(idx)];
            end
            g(i_loc,i_dx)=gramm('x',xs,'y',ys,'color',cols,'subset',find(contains(cols,pathnames(find(paths)))));
            g(i_loc,i_dx).stat_summary('type','quartile');
            if i_dx==1
                g(i_loc,i_dx).set_names('x','Amplitude (mA)','y',sprintf('%s\nRecruitment (%%)',elecLocStr),'color','Pathway');
            else
                g(i_loc,i_dx).set_names('x','Amplitude (mA)','y',' ','color','Pathway');
            end
            if i_loc==1
                g(i_loc,i_dx).set_title(sprintf('%0.1f mm',dx));
            end
            g(i_loc,i_dx).set_color_options('map',[pathcolors(plot_paths,:)]);
            g(i_loc,i_dx).set_order_options('color',0);
            g(i_loc,i_dx).set_layout_options('legend',false);
        end
        
    end
end
g.set_text_options('base_size',15)
g.draw()

for i_loc=1:length(elecLocStrs)
    for i_dx=1:length(dxs)
        g(i_loc,i_dx).facet_axes_handles.YLim=[-5 100];
    end
end
set(gcf,'Position',[608 494 896 282]);

% Dispersion plot --------------------------------------------- %
% figure; clear g;
for i_name=1:length(pathnames)
    pathname=pathnames{i_name};%'mHD';
    pp.(pathname)=[];
for i_elecLoc=1:length(elecLocStrs)
    elecLoc=elecLocStrs{i_elecLoc};
    for i_amp=1:length(amps)
        idx_hi=find(([RT2.(elecLoc).(polstr).EL]<29)&([RT2.(elecLoc).(polstr).dx]==0.5)&([RT2.(elecLoc).(polstr).ring]==1)&([RT2.(elecLoc).(polstr).pw]==60)&([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
        idx_med=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==1.0) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60) & ([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
        idx_lo=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==1.5) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60) & ([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
        pp.(pathname)=[pp.(pathname);0.5 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_hi,:),[0.25 0.5 0.75]),i_elecLoc;...
                       1.0 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_med,:),[0.25 0.5 0.75]),i_elecLoc;...
                       1.5 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_lo,:),[0.25 0.5 0.75]),i_elecLoc];
    end
end
end

pp.all={};

for i_name=1:length(pathnames)
    pathname=pathnames{i_name};
    
    ggk=num2cell(pp.(pathname)); ggk(:,7)={pathname};
    
    pp.all=[pp.all;ggk];
end

f=figure; set(f,'Position',[10 10 256 420]);
i_plot=1;
for i_path=1
    pathName='all';
    if ~strcmp(pathName,'pIC')
        if strcmp(pathName,'all')
            idxSub=1:length(pp.all);
        else
            idxSub=find(strcmp(pp.all(:,7),pathName));
        end
        for i=1:length(pathnames)
            if sum(strcmp(pathnames{i},unique(pp.all(idxSub,7))))
                plot_paths(i)=1;
            else
                plot_paths(i)=0;
            end
        end

% -------------------------- Relative Dispersion --------------------------------------- %
        g=gramm('x',[pp.all{:,1}],'y',[([pp.all{:,5}]-[pp.all{:,3}])./[pp.all{:,4}]],'subset',[pp.all{:,4}]>0)
        g.set_names('x','Precision (mm)','y','Dispersion');
% -------------------------- Absolute Dispersion --------------------------------------- %
        g.set_color_options('map',[0.6 0.6 0.6]);
        g.stat_boxplot()
        g.set_text_options('base_size',15)
        fvv=figure; 
        g.draw() 
  
% -------------------------- Relative Dispersion --------------------------------------- %
        x=[pp.all{idxSub,1}]; 
        y=[([pp.all{idxSub,5}]-[pp.all{idxSub,3}])./[pp.all{idxSub,4}]];
% -------------------------- Absolute Dispersion --------------------------------------- %      
        idx=find(y<0,1);
        if ~isempty(idx)
            keyboard()
        end

        x(find(([pp.all{idxSub,4}])==0))=[];
        y(find(([pp.all{idxSub,4}])==0))=[]; 
        x2=[pp.all{idxSub,2}]; 
        x2(find(isinf(y)))=[]; x(find(isinf(y)))=[]; y(find(isinf(y)))=[]; 
        try
            mdl=fitlm(x(~isnan(y)),y(~isnan(y)),'VarNames',{'Precision',sprintf('%s: IQR/Median',pathName)})

            set(0,'CurrentFigure',f);
            if ~strcmp(pathName,'all')
                subplot(1,length(pathnames),i_plot)
            end
            i_plot=i_plot+1;
            plot(mdl)
            idx1=find([pp.all{idxSub,1}]==0.5);
            idx2=find([pp.all{idxSub,1}]==1);
            idx3=find([pp.all{idxSub,1}]==1.5);
            hold on
            set(gca,'YLim',[0 45])
            legend('off')
            title(pathName)
        catch
            set(gca,'YLim',[0 45])
        end
    end
end
set(fvv,'Position',[10 10 256 282]);


% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 10: Effect of electrode precision
% Recruitment plot --------------------------------------------- %
polstr='cathodic';
elecLocStrs={'pmdSTN','dlSTN','cSTN'};
clear pp
clear g
pathnames={'CT'};
pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[1 1 0 1 1 1 1 1 1];
figure
plot_paths=find(paths);
pathcolors=[92 172 238;...
    255 164 0;...
    125 38 205;...
    0 0 255;...
    0 205 0;...
    100 100 100;...%200 200 200;...
    255 20 147;...
    0  0 0;...%183 171 80;...
    165 42 42]./255/1;
for i_loc=1:length(elecLocStrs)
    elecLoc=elecLocStrs{i_loc};
    elecLocStr=elecLocStrs{i_loc};
    amps=unique(RT2.(elecLoc).(polstr).Amp);
    for i_dx=1:length(dxs)
        dx=dxs(i_dx);
        cstr=[];
        xs=[]; ys=[]; cols=[]; colnames={};
        idx=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==dx) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60));
        if ~isempty(idx)
            for i=1:sum(paths)
                pathname=pathnames{plot_paths(i)}; colnames{length(idx)}='a';
                [colnames{:}]=deal(pathname);
                cols=[cols;colnames'];
                xs=[xs;RT2.(elecLoc).(polstr).Amp(idx)];
                ys=[ys;RT2.(elecLoc).(polstr).(pathname)(idx)];
            end
            g(i_loc,i_dx)=gramm('x',xs,'y',ys,'color',cols,'subset',find(contains(cols,pathnames(find(paths)))));
            g(i_loc,i_dx).stat_summary('type','quartile');
            if i_dx==1
                g(i_loc,i_dx).set_names('x','Amplitude (mA)','y',sprintf('%s\nRecruitment (%%)',elecLocStr),'color','Pathway');
            else
                g(i_loc,i_dx).set_names('x','Amplitude (mA)','y',' ','color','Pathway');
            end
            if i_loc==1
                g(i_loc,i_dx).set_title(sprintf('%0.1f mm',dx));
            end
            g(i_loc,i_dx).set_color_options('map',[pathcolors(plot_paths,:)]);
            g(i_loc,i_dx).set_order_options('color',0);
            g(i_loc,i_dx).set_layout_options('legend',false);
        end
        
    end
end
g.set_text_options('base_size',15)
g.draw()

for i_loc=1:length(elecLocStrs)
    for i_dx=1:length(dxs)
        g(i_loc,i_dx).facet_axes_handles.YLim=[-5 100];
    end
end
set(gcf,'Position',[608 494 896 846]);

% Dispersion plot --------------------------------------------- %
clear g;
for i_name=1:length(pathnames)
	pathname=pathnames{i_name};%'mHD';
	pp.(pathname)=[];
	for i_elecLoc=1:length(elecLocStrs)
	    elecLoc=elecLocStrs{i_elecLoc};
	    for i_amp=1:length(amps)
	        idx_hi=find(([RT2.(elecLoc).(polstr).EL]<29)&([RT2.(elecLoc).(polstr).dx]==0.5)&([RT2.(elecLoc).(polstr).ring]==1)&([RT2.(elecLoc).(polstr).pw]==60)&([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
	        idx_med=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==1.0) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60) & ([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
	        idx_lo=find(([RT2.(elecLoc).(polstr).EL]<29) & ([RT2.(elecLoc).(polstr).dx]==1.5) & ([RT2.(elecLoc).(polstr).ring]==1) & ([RT2.(elecLoc).(polstr).pw]==60) & ([RT2.(elecLoc).(polstr).Amp==amps(i_amp)]));
	        pp.(pathname)=[pp.(pathname);0.5 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_hi,:),[0.25 0.5 0.75]),i_elecLoc;...
	                       1.0 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_med,:),[0.25 0.5 0.75]),i_elecLoc;...
	                       1.5 amps(i_amp) quantile(RT2.(elecLoc).(polstr).(pathname)(idx_lo,:),[0.25 0.5 0.75]),i_elecLoc];
	    end
	end
end

pp.all={};

for i_name=1:length(pathnames)
    pathname=pathnames{i_name};
    
    ggk=num2cell(pp.(pathname)); ggk(:,7)={pathname};
    
    pp.all=[pp.all;ggk];
end

f=figure; set(f,'Position',[10 10 256 420]);
i_plot=1;
for i_path=1
    pathName='all';
    if ~strcmp(pathName,'pIC')
        if strcmp(pathName,'all')
            idxSub=1:length(pp.all);
        else
            idxSub=find(strcmp(pp.all(:,7),pathName));
        end
        for i=1:length(pathnames)
            if sum(strcmp(pathnames{i},unique(pp.all(idxSub,7))))
                plot_paths(i)=1;
            else
                plot_paths(i)=0;
            end
        end

% -------------------------- Relative Dispersion --------------------------------------- %
        g=gramm('x',[pp.all{:,1}],'y',[([pp.all{:,5}]-[pp.all{:,3}])./[pp.all{:,4}]],'subset',[pp.all{:,4}]>0)
        g.set_names('x','Precision (mm)','y','Dispersion');
% -------------------------- Absolute Dispersion --------------------------------------- %
        g.set_color_options('map',[0.6 0.6 0.6]);
        g.stat_boxplot()
        g.set_text_options('base_size',15)
        fvv=figure; 
        g.draw() 
  
% -------------------------- Relative Dispersion --------------------------------------- %
        x=[pp.all{idxSub,1}]; 
        y=[([pp.all{idxSub,5}]-[pp.all{idxSub,3}])./[pp.all{idxSub,4}]];
% -------------------------- Absolute Dispersion --------------------------------------- %      
        idx=find(y<0,1);
        if ~isempty(idx)
            keyboard()
        end

        x(find(([pp.all{idxSub,4}])==0))=[];
        y(find(([pp.all{idxSub,4}])==0))=[]; 
        x2=[pp.all{idxSub,2}]; 
        x2(find(isinf(y)))=[]; x(find(isinf(y)))=[]; y(find(isinf(y)))=[]; 
        try
            mdl=fitlm(x(~isnan(y)),y(~isnan(y)),'VarNames',{'Precision',sprintf('%s: IQR/Median',pathName)})

            set(0,'CurrentFigure',f);
            if ~strcmp(pathName,'all')
                subplot(1,length(pathnames),i_plot)
            end
            i_plot=i_plot+1;
            plot(mdl)
            idx1=find([pp.all{idxSub,1}]==0.5);
            idx2=find([pp.all{idxSub,1}]==1);
            idx3=find([pp.all{idxSub,1}]==1.5);
            hold on
            set(gca,'YLim',[0 45])
            legend('off')
            title(pathName)
        catch
            set(gca,'YLim',[0 45])
        end
    end
end
set(fvv,'Position',[10 10 256 282]);

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 11: 
pws=unique(RT2.dlSTN.cathodic.pw); contacts=567;
clear g;
figure
elecLoc='dlSTN';
% Recruitment plot
[idx_subset,~]=find(ismember(RT2.(elecLoc).(polstr).pw,pws)&ismember(RT2.(elecLoc).(polstr).Contact,contacts)&ismember(RT2.(elecLoc).(polstr).dx,dxs));
g(1,1)=gramm('x',[RT2.(elecLoc).(polstr).Amp(idx_subset);RT2.(elecLoc).(polstr).Amp(idx_subset)],'y',[RT2.(elecLoc).(polstr).mIC(idx_subset);RT2.(elecLoc).(polstr).mHD(idx_subset)],'color',[RT2.(elecLoc).(polstr).pw(idx_subset)-60 RT2.(elecLoc).(polstr).pw(idx_subset)+60],'linestyle',[RT2.(elecLoc).(polstr).pw(idx_subset),RT2.(elecLoc).(polstr).pw(idx_subset)]);
g(1,1).stat_summary('type','quartile');
g(1,1).set_color_options('map',[pathcolors(6,:);pathcolors(6,:)./1;pathcolors(6,:)./1;pathcolors(7,:);pathcolors(7,:)./1;pathcolors(7,:)./1;],'legend','merge')
g(1,1).set_names('x','Amplitude (mA)','y','Recruitment (%)','LineStyle',' ','Color',' ')
g(1,1).set_text_options('base_size',15)
g(1,1).set_layout_options('legend_position',[0.15 0.7 0.4 0.3])
% Therapeutic window plot
g(1,2)=gramm('x',[RT2.(elecLoc).(polstr).pw(idx_subset)],'y',[RT2.(elecLoc).(polstr).mHD(idx_subset)-RT2.(elecLoc).(polstr).mIC(idx_subset)],'color',[RT2.(elecLoc).(polstr).pw(idx_subset)],'subset',[RT2.(elecLoc).(polstr).mIC(idx_subset)>0&RT2.(elecLoc).(polstr).Amp(idx_subset)<6]);
g(1,2).stat_boxplot()
g(1,2).set_color_options('map',[pathcolors(6,:);pathcolors(6,:);pathcolors(6,:);pathcolors(6,:)]*2)%,'legend','merge')
g(1,2).set_names('x','Pulse Width (  s)','y',sprintf('Absolute difference in recruitment\nmHD-mIC ( D %%)'),'Color',sprintf('PW\n(us)'));
g(1,2).set_text_options('base_size',15)
g(1,2).set_layout_options('legend','false')
g.draw()
% modify plots
g(1,2).facet_axes_handles.XTick=[30 60 120];
g(1,2).facet_axes_handles.XTickLabel
g(1,1).facet_axes_handles.YLim(2)=105;
g(1,2).facet_axes_handles.YLim(2)=23;
% linear regression
idx_subset2=idx_subset(find([RT2.(elecLoc).(polstr).mIC(idx_subset)>0&RT2.(elecLoc).(polstr).Amp(idx_subset)<6]));
x=[RT2.(elecLoc).(polstr).pw(idx_subset2)];
y=[RT2.(elecLoc).(polstr).mHD(idx_subset2)-RT2.(elecLoc).(polstr).mIC(idx_subset2)];
mdl=fitlm(x(~isnan(y)),y(~isnan(y)),'VarNames',{'Pulse width','mHD-mIC'})

% ------------------------------------------------------------------------------------------------------------------------------------------ %
%% Figure 12: Effect of directionality
% choose a contact to compare to ring mode (567)
contactList=[5 6 7];

clc;
elecLoc='dlSTN'; elecLocstr=elecLoc;
polstr='cathodic';
pws=[60];
dxs=[0.5];

pathcolors=[92 172 238;...
255 164 0;...
125 38 205;...
0 0 255;...
0 205 0;...
100 100 100;...%200 200 200;...
255 20 147;...
0  0 0;...%183 171 80;...
165 42 42]./255;
colorvals=[0.3010 0.7450 0.9330;0 0.4470 0.7410;0.3 0.1790 0.6790];

cstr=[];

pathnames={'P','CT','ML','PS','STP','mIC','mHD','pIC','pHD'};
paths=[1 1 0 1 1 1 1 1 1]; plot_paths=find(paths);
clear g

empty=[];
[idx_subset,~]=find(ismember(RT2.(elecLoc).(polstr).pw,pws)&ismember(RT2.(elecLoc).(polstr).Contact,[contacts, 567])&ismember(RT2.(elecLoc).(polstr).dx,dxs));
for i_c=1:3
    contacts=contactList(i_c);
    [idx_subset,~]=find(ismember(RT2.(elecLoc).(polstr).pw,pws)&ismember(RT2.(elecLoc).(polstr).Contact,[contacts, 567])&ismember(RT2.(elecLoc).(polstr).dx,dxs));
    for i=1:length(plot_paths)
        pathname=pathnames{plot_paths(i)};

    % --------- str-Dur curve --------- %
        g(1,i)=gramm('x',RT2.(elecLoc).(polstr).Amp(idx_subset),'y',RT2.(elecLoc).(polstr).(pathname)(idx_subset),'color',RT2.(elecLoc).(polstr).Contact(idx_subset));
        g(1,i).stat_summary('type','quartile');
        if i==1&contacts==7
            g(1,i).set_names('x','Amplitude (mA)','y',sprintf('%s\nRecruitment (%%)',elecLocstr),'color','Contact');
        elseif i==1
            g(1,i).set_names('x',' ','y',sprintf('%s\nRecruitment (%%)',elecLocstr),'color','Contact');
        elseif contacts==7
            g(1,i).set_names('x','Amplitude (mA)','y',' ','color','Contact');
        else
            g(1,i).set_names('x',' ','y',' ','color','Contact');
        end
        g(1,i).set_title(pathname);
    %     g(1,i).set_point_options('markers',{num2str(contacts),'s'},'base_size',5);
        g(1,i).set_layout_options('legend',false)
        g(1,i).set_color_options('map',[pathcolors(plot_paths(i),:)/2;pathcolors(plot_paths(i),:)])
    end
    ff=figure; set(ff,'Position',[10 10 1764 237]); drawnow(); pause(1);
    g.set_text_options('base_size',15)
    g.draw()
    try
        g.draw()
        if ~isempty(empty)
    %         keyboard()
            for i=1:size(empty,1)
                for ii=1:length(g(empty(i,1),empty(i,2)).facet_axes_handles.Children)
                    g(empty(i,1),empty(i,2)).facet_axes_handles.Children(ii).Visible='off';
                end
            end
        end
    catch
        % if failed bc of empty subplot
        break
    end
    for i=1:size(g,1)
        for j=1:size(g,2)
            if ~isempty(g(i,j).legend_axe_handle)
    %             g(i,j).facet_axes_handles.XLim=[0.5 5]; % g(i,j).facet_axes_handles.XLim=[0.5 5];
                g(1,j).facet_axes_handles.YLim=[0 100];
                g(i,j).facet_axes_handles.YGrid='off';
            end
            % add markers
    %         keyboard()
            marker_bool=0;
            for iiii=1:length(g(i,j).facet_axes_handles.Children)
                while marker_bool==0
                    if isgraphics(g(i,j).facet_axes_handles.Children(length(g(i,j).facet_axes_handles.Children)-iiii),'line')
                        set(gcf,'CurrentAxes',g(i,j).facet_axes_handles)
                        text(g(i,j).facet_axes_handles.Children(length(g(i,j).facet_axes_handles.Children)-iiii).XData,g(i,j).facet_axes_handles.Children(length(g(i,j).facet_axes_handles.Children)-iiii).YData,num2str(contacts),'HorizontalAlignment','center','Color',g(i,j).facet_axes_handles.Children(length(g(i,j).facet_axes_handles.Children)-iiii).Color,'FontSize',20);
                    end
                    marker_bool=1;
                end
            end
        end
    end
    set(gcf,'Name',elecLoc)
end




























